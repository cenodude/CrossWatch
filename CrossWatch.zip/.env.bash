export PATH="$(pwd)/.venv/Scripts:$PATH"
